# 1、Qt的应用开发 之 Demo_VLC_Qt
Qt+VLC简单的使用显示视频示例，vlc播放视频，要比QMediaPlayer实用的多，并且同时运行20个视频时不会出现卡顿。 <BR/>
<BR/> 
# 2、更新信息
开发者：沙振宇（沙师弟专栏）<BR/>
创建时间：2017-5-23<BR/>
最后一次更新时间：2019-12-5<BR/>
此项目CSDN博客：Qt+VLC简单的使用显示视频Demo <BR/>
此项目博客地址：https://shazhenyu.blog.csdn.net/article/details/72673677 <BR/>
<BR/>
# 3、使用方法
## 3.1、使用前
使用前先解压vlc_win32.zip，再使用哦~<BR/>
## 3.2、软件使用过程
![image](https://github.com/ShaShiDiZhuanLan/Demo_VLC_Qt/blob/master/%E8%BD%AF%E4%BB%B6%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E1.png)
![image](https://github.com/ShaShiDiZhuanLan/Demo_VLC_Qt/blob/master/%E8%BD%AF%E4%BB%B6%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E2.png)
